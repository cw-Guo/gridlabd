PYPOWER documentation
=====================

.. only:: html

  Download `PDF <rwl.github.io/PYPOWER/PYPOWER.pdf>`_

  Contents:

.. toctree::
  :maxdepth: 2

  intro
  copyright
  install
  usage
  solvers
  support

.. only:: html

  `API documentation <https://rwl.github.io/PYPOWER/api>`_

Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
